#include <stdio.h>
#include <stdlib.h>


int main()
{
    int vec[5] = {15,16,17,18,19}; 
    int x;
    printf("El vector vale %p\n",vec);
    printf("vec[3] = %d\n",vec[3]);
    printf("*(vec+3) = %d\n",*(vec+3));
    printf("Mostramos todo el vector:\n");
    for (int i=0;i<5;i++)
        printf("*(vec+%d) = %d\n",i,*(vec+i));
    
    return 0;
}
