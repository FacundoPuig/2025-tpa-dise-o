#include <stdio.h>
     
void Procedimiento1(int x)
{
    printf( "Estamos en procedimiento 1. El parámetro es= %d\n", x);
    return;
}

/*Procedimiento2, recibe dos parámetros, un entero, y una función que no debe tener
parámetros formales */
 void Procedimiento2(int x, void (*ptr_func)())
{
    printf( "Estamos en procedimiento 2. EL parámetro x es= %d\n", x);
    if(ptr_func!=NULL)
        ptr_func();  //Usando el puntero para retrollamar
    else
        printf("No se ha pasado ninguna función CALLBACK.");
    return;
}

void func_call_back1()
{
    printf( "CALLBACK 1\n");
    return;
}

void func_call_back2()
{
    printf( "CALLBACK 2\n");
    return;
}
int main()
{   // Definimos dos punteros a funciones
    void (*ptr_func_1)(int)=NULL;
    void (*ptr_func_2)(int, void (*call_back_func)() )=NULL;    
    //Usamos el primero
    ptr_func_1 = Procedimiento1;
    printf("MAIN LINEA 30: La dirección del primer puntero is %p\n",ptr_func_1);
    ptr_func_1(1001); 
    //Usamos el segundo
    ptr_func_2 = Procedimiento2;    
    printf("MAIN LINEA 34: Probando funciones callback \n");    
    ptr_func_2(1002,func_call_back1);     
    ptr_func_2(1003,func_call_back2); 
    ptr_func_2(1004,NULL); 
    return 0;
}