#include <stdio.h>

void unSub()
{
    int tam;
    printf("Ingrese un tamaño:\n");
    scanf("%d",&tam);
    int v[tam];
    for (int i=0;i<tam;i++)
        v[i] = 25;
    for (int i=0;i<tam;i++)
        printf("v[%d]=%d\n",i,v[i]);
    return;
}

int main()
{
    printf("Estamos trabajando con memoria\n");
    unSub();
    return 0;
}
