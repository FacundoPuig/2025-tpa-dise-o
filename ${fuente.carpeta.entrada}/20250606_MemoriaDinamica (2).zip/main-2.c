#include <stdio.h>


int main()
{
    int *p1,*p2,*p3;
    int x = 555;
    p1 = &x;
    
    printf("La dirección de la variable x es &x=%p\n", &x);
    printf("*p1=%d\n", *p1);
    p2= p1;
    p3= p1;
    *p3 = 27;
    printf("----------------------\n");
    printf("*p1=%d\n", *p1);
    printf("*p2=%d\n", *p2);
    printf("*p3=%d\n", *p3);
    printf("x=%d\n", x);
    return 0;
}
